document.addEventListener('DOMContentLoaded', function() {
  // Menú lateral: abrir y cerrar
  var menuToggle = document.getElementById('menu-toggle');
  var sidenav = document.getElementById('sidenav');
  var closeNav = document.getElementById('close-nav');

  menuToggle.addEventListener('click', function() {
    sidenav.style.width = "250px";
  });
  closeNav.addEventListener('click', function() {
    sidenav.style.width = "0";
  });

  // Ejemplo de alerta en JavaScript
  var btnAlert = document.getElementById('btnAlert');
  if (btnAlert) {
    btnAlert.addEventListener('click', function() {
      alert('¡Hola! Esto es un ejemplo de alerta en JavaScript.');
    });
  }

  // Validación del formulario
  var form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', function(event) {
      var name = document.getElementById('name').value.trim();
      var email = document.getElementById('email').value.trim();
      var mensaje = document.getElementById('mensaje').value.trim();
      var pais = document.getElementById('pais').value;
      var checkboxes = document.querySelectorAll('input[name="intereses"]:checked');

      if (name === '' || email === '' || mensaje === '' || pais === "" || checkboxes.length === 0) {
        event.preventDefault();
        alert('Por favor, completa todos los campos obligatorios y selecciona al menos un interés.');
      } else {
        console.log('Formulario enviado correctamente.');
      }
    });
  }

  // Botón de información extra
  var btnInfo = document.getElementById('btnInfo');
  if (btnInfo) {
    btnInfo.addEventListener('click', function() {
      alert('Información extra: se utiliza input pattern, validación HTML5 y JavaScript para el formulario.');
    });
  }

  // Demo jQuery: Mostrar/Ocultar mensaje
  $('#toggleMsg').click(function() {
    $('#msg').toggle('slow');
  });
});
